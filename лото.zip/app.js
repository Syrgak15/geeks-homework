const generateButton = document.querySelector(".btn-generate");
const numberOne = document.querySelector(".number-1");
const numberTwo = document.querySelector(".number-2");
const numberThree = document.querySelector(".number-3");
const numberFour = document.querySelector(".number-4");
const numberFive = document.querySelector(".number-5");
const numberSix = document.querySelector(".number-6");

let firstNumber = 0;
let secondNumber = 0;
let thirdNumber = 0;
let fourthNumber = 0;
let fifthNumber = 0;
let sixthNumber = 0;

function getRandomNumber(min, max) {
    return Math.round(min + Math.random() * (max - min));
}

function insertNumber() {
    numberOne.textContent = firstNumber;
    numberTwo.textContent = secondNumber;
    numberThree.textContent = thirdNumber;
    numberFour.textContent = fourthNumber;
    numberFive.textContent = fifthNumber;
    numberSix.textContent = sixthNumber;

    firstNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    secondNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    thirdNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    fourthNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    fifthNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    sixthNumber = getRandomNumber(1, 99).toString().padStart(2, '0');
    return firstNumber + secondNumber + thirdNumber + fourthNumber + fifthNumber + sixthNumber;
}

generateButton.addEventListener("click", insertNumber);